# Well-Tools

name_tool       =  "Well"
type_tool       =  "Multi-Tools"
version_tool    =  "2.0"
coding_tool     =  "Python 3"
language_tool   =  "EN/FR"
creator         =  "Well Dekur"
platform        =  "Windows 10/11 & Linux"
github_tool     =  "          𝐁𝐲 𝐖𝐞𝐋𝐋 𝐃𝐞𝐤𝐮𝐑"
url_downloads   =  "https://github.com/WellDekur/Well-Tools"