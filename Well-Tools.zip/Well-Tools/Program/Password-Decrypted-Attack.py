# Well-Tools

from Config.Util import *
from Config.Config import *
try:
    import bcrypt
    import hashlib
    import random
    import string
    import threading
    import time
    import base64
    from hashlib import pbkdf2_hmac
except Exception as e:
    ErrorModule(e)

Title(f"Password Decrypted")

try:
    Slow(f"""{decrypted_banner}
 {BEFORE}01{AFTER}{white} BCRYPT
 {BEFORE}02{AFTER}{white} MD5
 {BEFORE}03{AFTER}{white} SHA-1
 {BEFORE}04{AFTER}{white} SHA-256
 {BEFORE}05{AFTER}{white} PBKDF2 (SHA-256)
 {BEFORE}06{AFTER}{white} Base64 Decode
    """)

    choice = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Encryption Method -> {reset}")

    if choice not in ['1', '01', '2', '02', '3', '03', '4', '04', '5', '05', '6', '06']:
        ErrorChoice()

    encrypted_password = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Encrypted Password -> {white}")

    try:
        threads_number = int(input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Threads Number -> {white}"))
    except:
        ErrorNumber()
        
    try:
        characters_number = int(input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Password Characters Number Max -> {white}"))
    except:
        ErrorNumber()

    Title(f"Password Decrypted - Encrypted Password: {encrypted_password}")
    print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Password cracking by brute force.. (very long depending on the number of characters){reset}")

    password = False
    generated_passwords = set()

    salt = "this_is_a_salt".encode('utf-8')
    all_characters = string.ascii_letters + string.digits + string.punctuation
    all_characters_len = len(all_characters)

    def ErrorDecrypted():
        encryption_map = {
            '1': 'BCRYPT', '2': 'MD5', '3': 'SHA-1', '4': 'SHA-256', '5': 'PBKDF2 (SHA-256)', '6': 'Base64 Decode'
        }
        encryption = encryption_map.get(choice, "Unknown")
        print(f'{BEFORE + current_time_hour() + AFTER} {ERROR} The encryption "{white}{encrypted_password}{red}" is not accepted by "{white}{encryption}{red}".')
        Continue()
        Reset()

    def CheckPassword(password_test):
        try:
            if choice in ['1', '01']:
                return bcrypt.checkpw(password_test.encode('utf-8'), encrypted_password.encode('utf-8'))
            elif choice in ['2', '02']:
                return hashlib.md5(password_test.encode('utf-8')).hexdigest() == encrypted_password
            elif choice in ['3', '03']:
                return hashlib.sha1(password_test.encode('utf-8')).hexdigest() == encrypted_password
            elif choice in ['4', '04']:
                return hashlib.sha256(password_test.encode('utf-8')).hexdigest() == encrypted_password
            elif choice in ['5', '05']:
                return pbkdf2_hmac('sha256', password_test.encode('utf-8'), salt, 100000).hex() == encrypted_password
            elif choice in ['6', '06']:
                return base64.b64decode(encrypted_password.encode('utf-8')).decode('utf-8') == password_test
            return False
        except:
            ErrorDecrypted()

    def GeneratePassword(characters_number):
        return ''.join(random.choice(all_characters) for _ in range(random.randint(1, characters_number)))

    def TestDecrypted():
        global password
        while not password:
            password_test = GeneratePassword(characters_number)
            if password_test not in generated_passwords:
                generated_passwords.add(password_test)
                if CheckPassword(password_test):
                    password = True
                    print(f'{BEFORE + current_time_hour() + AFTER} {ADD} Password: {white}{password_test}{reset}')
                    time.sleep(1)
                    Continue()
                    Reset()

    def Request():
        from concurrent.futures import ThreadPoolExecutor

        try:
            with ThreadPoolExecutor(max_workers=threads_number) as executor:
                executor.map(lambda _: TestDecrypted(), range(threads_number))
        except Exception as e:
            ErrorNumber()

    while not password:
        Request()

except Exception as e:
    Error(e)
